const CACHE='nexora-shell-v3';
const CORE=['/','/index.html','/nexora-logo.png','/favicon.png','/manifest.webmanifest'];
self.addEventListener('install',event=>{event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(CORE)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',event=>{event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',event=>{
 const req=event.request;
 if(req.method!=='GET') return;
 const url=new URL(req.url);
 if(url.origin!==self.location.origin || url.pathname.startsWith('/api/')) return;
 // Always prefer the network for application code and styles so deployments cannot
 // leave users on an old broken bundle.
 if(/\.(?:js|jsx|css|map)$/.test(url.pathname) || url.pathname.startsWith('/assets/')){
   event.respondWith(fetch(req).catch(()=>caches.match(req)));
   return;
 }
 if(req.mode==='navigate'){
   event.respondWith(fetch(req).then(res=>{const copy=res.clone();caches.open(CACHE).then(c=>c.put('/index.html',copy));return res}).catch(()=>caches.match('/index.html')));
   return;
 }
 event.respondWith(caches.match(req).then(cached=>cached||fetch(req).then(res=>{
   if(res.ok){const copy=res.clone();caches.open(CACHE).then(c=>c.put(req,copy))}
   return res;
 }).catch(()=>cached)));
});